﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace EJOBFILE
{
    public partial class Service1 : ServiceBase
    {
        private Timer timer1 = null;
        private static readonly ILog _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        static bool folderOK = false;
        List<string> folderNames = new List<string> { };
        List<string> PINames = new List<string> { };
        List<string> multiRev = new List<string> { };
        static bool pi_Doc = false;
        static bool ca_Doc = false;
        static bool sra_Doc = false;
        static string consoDir;
        string path = "\\\\in-che-fs-01\\India_Share\\DO-IT_Team\\E Job File";
        //string path = "E:\\DO-IT_Team\\E Job File";
        SqlConnection conn = null;

       

        public Service1()
        {
            InitializeComponent();
            XmlConfigurator.Configure();
            


        }

        protected override void OnStart(string[] args)
        {
            //Program start. Uses timer to adjust the timing.
            folderNames.Clear();
            PINames.Clear();
            timer1 = new Timer();
            this.timer1.Interval = 6000; //5mins interval
            //this.timer1.Interval = 15000; //30 sec interval testing
            this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Tick);
            timer1.Enabled = true;
            _log.Info ("Service Started successfully - India");
           


        }

        protected override void OnStop()
        {

            _log.Info("Service Stopped");
        }

        private void timer1_Tick(object sender, ElapsedEventArgs e)
        {
            EJOBFileMonitor();
        }

        private void EJOBFileMonitor()
        {

            //Main Logic here

            conn = new SqlConnection("Data Source = SG-SIN-SQL-01\\sg2014prod;Initial Catalog=inet;User id=sgsqladm;Password=Buckman1234;");

            conn.Open();
            try
            {
                //Root folder

                // T:\\DO - IT_Team\\E Job File
                //path to where the root folder of the job file will be.
                //string path = "\\\\sg-sin-fs-03\\Team\\DO-IT_Team\\E Job File";

                //get all the subdirectories under it
                string[] myDirectories = Directory.GetDirectories(path);

                //Print out the sub directory
                _log.Info("All the subdirectories are: " + myDirectories.ToArray().ToString());



                foreach (string directory in myDirectories)
                {

                    //Check the following nnaming sequence
                    /*
                     * 
                     * Checking is based on the country followed by PI and 6 digit numbers and then company name
                     * 
                     * */


                    int fileCount = Directory.GetFiles(directory, "*.*", SearchOption.TopDirectoryOnly).Length;
                    _log.Info("Number of files in " + directory + " : " + fileCount);

                    _log.Info("The directory is we are accessing: " + Path.GetFileName(directory));

                    //Call nameChecker to check on the nameChecker to check for valid folder names before checking for valid documents and minimum 3 documents.
                    //But India Only 1 File to check, so instead of >2 files used by SG, they only need > 0.
                    if (folderNameChecker(Path.GetFileName(directory).Trim().Split(' ')) && fileCount > 0)
                    {
                        //once the main folder has satisfied the criteria check, we will look into the minimum 3 files neeeded
                        _log.Info("Searching directory: " + Path.GetFileName(directory));

                        consoDir = Path.GetFileName(directory);


                        if (Directory.Exists(directory))
                        {
                            // This path is a directory

                            ProcessDirectory(directory);

                        }

                        else if (File.Exists(directory))
                        {
                            // This path is a file



                            ProcessFile(directory);




                        }
                        else
                        {
                            _log.Info(directory+" is not a valid file or directory.");
                        }


                    }
                    else
                    {
                        //if the main folder does not satisfy the criteria or not sufficient files inside.
                        _log.Info(directory + " does not satisfy the criteria");

                    }

                }

                if (folderNames.Count > 0)
                {
                    _log.Info("Number of folders: "+ folderNames.ToArray().ToString());
                    _log.Info("Email Sent");
                    sendNotification(folderNames);
                }
                else
                {
                    _log.Info("No email has been sent as it does not have any file processe.");
                }

            }
            catch (Exception ex)
            {
                _log.Info("Error =" + ex.ToString());
            }
        }




        public bool folderNameChecker(string[] folderName)
        {
            //the 3 conditions for a valid foldername

            bool condition_Cty = false;
            bool condition_PI = false;
            bool condition_PINumber = false;

            //Split it into multiple parts
            //eg SG PI XXXXXX COMPANY NAME

         //   string countryIdentifier = "";
         //   string piCodeIdentifier = "";
         //   string piNumberIdentifier = "";
            string companyName = "";

            for (int myFolderName = 3; myFolderName < folderName.Length; myFolderName++)
            {
                companyName = companyName + " " + folderName[myFolderName];
            }

            foreach (string name in folderName)
            {



                if (name.Trim().ToUpper().Equals("SG") || name.Trim().ToUpper().Equals("ID") || name.Trim().ToUpper().Equals("IN"))
                {
                    condition_Cty = true;
                }
                if (name.Trim().ToUpper().Equals("PI"))
                {
                    condition_PI = true;
                }
                if (name.Trim().Length.Equals(6) && int.TryParse(name.Trim(), out int resultOutput))
                {
                    condition_PINumber = true;
                }


            }

            if (condition_Cty && condition_PI && condition_PINumber)
            {
                _log.Info(companyName.Trim() + " Successful");



                return true;
            }
            else
            {
                return false;
            }


        }

        public void ProcessDirectory(string targetDirectory)
        {
            // Process the list of files found in the directory.

            _log.Info(targetDirectory.Remove(0, targetDirectory.Length));
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            // Recurse into subdirectories of this directory.
            /*
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
            { 
            Console.WriteLine(subdirectory.Remove(0, subdirectory.Length));
            ProcessDirectory(subdirectory);
            }
            */
        }

        // Insert logic for processing found files here.
        public void ProcessFile(string path)
        {

            

            //To process the file here.
            FileInfo info = new FileInfo(path);
            string name = info.Name;
            string extension = info.Extension; // Has period
            DateTime fileTimeInfo = info.CreationTime;
            fileTimeInfo = info.LastAccessTime;
            fileTimeInfo = info.LastWriteTime;

            _log.Info("Current processing file: " + name + " ");
            _log.Info("Current filename: " + extension + " ");
            Console.WriteLine(fileTimeInfo);
            Console.WriteLine(fileTimeInfo);
            Console.WriteLine(fileTimeInfo);

            /*
             * India Do Not Have PI or CA. They only have 1 File, that is SRA
             * 
            if (name.Trim().ToUpper().Substring(0, 2).Equals("PI"))
            {
                pi_Doc = true;
            }
            if (name.Trim().ToUpper().Substring(0, 2).Equals("CA"))
            {
                ca_Doc = true;
            }
            */

            if (name.Trim().ToUpper().Substring(0, 3).Equals("SRA"))
            {
                sra_Doc = true;
            }

            _log.Info("Checking of " + name + " done");
            _log.Info("Checking of pi_Doc " + pi_Doc);
            _log.Info("Checking of ca_Doc " + ca_Doc);
            _log.Info("Checking of sra_Doc " + sra_Doc);



            //Not for India. Only 1 SRA
            //if (pi_Doc & ca_Doc & sra_Doc)

            if (sra_Doc)
            {

                folderOK = true;
                _log.Info("Folder passed: " + folderOK);
                

            }
            else
            {
                folderOK = false;
                

            }


            if (folderOK)
            {
                try
                {
                pi_Doc = false;
                ca_Doc = false;
                sra_Doc = false;
                _log.Info("Reset Folder: " + pi_Doc + ca_Doc + sra_Doc);
                _log.Info("Consolidate Folder: " + consoDir);
                SqlCommand cmd = new SqlCommand("EJOBFILE", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@JOBNAME", consoDir);
                cmd.Parameters.AddWithValue("@DATEOFJOB", DateTime.ParseExact(DateTime.Today.ToString("dd/MM/yyyy"), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@PROCESSED", "YES");
                cmd.ExecuteNonQuery();
                consolidateFolders(consoDir);
                    

                }
                catch(Exception e)
                {
                    _log.Info(e.ToString());
                }




            }

            folderOK = false;
            


        }


        public List<string> consolidateFolders(string folderName)
        {

            _log.Info("Adding: " + folderName);
            folderNames.Add(folderName);

            //RenameFolder to indicate processed.
            _log.Info("My path is: " + path + "\\" + folderName);
            System.IO.Directory.Move(path + "\\" + folderName, path + "\\" + "_" + folderName);



            return folderNames;

        }

        //only India has this attachment of SRA in email

        public string AttachFile(string FolderName)
        {
            _log.Info("Attachment Path: "+ FolderName);
            String fullPath =  FolderName;
            //To process the file here.
            FileInfo info = new FileInfo(fullPath);
            string name = info.Name;
            string extension = info.Extension; // Has period
            DateTime fileTimeInfo = info.CreationTime;
            fileTimeInfo = info.LastAccessTime;
            fileTimeInfo = info.LastWriteTime;

            _log.Info("Finding attachment file: " + name + " ");
            _log.Info("Current filename: " + extension + " ");
            Console.WriteLine(fileTimeInfo);
            Console.WriteLine(fileTimeInfo);
            Console.WriteLine(fileTimeInfo);

            if (name.Trim().ToUpper().Substring(0, 3).Equals("SRA"))
            {
                _log.Info("Return: "+ fullPath + "\\" + name);
                return fullPath + "\\"+name;
            }
            else
            {
                _log.Info("Return Nothing");
                return "";
            }


        }


        public string ProcessAttachFile(string targetDirectory)
        {
            // Process the list of files found in the directory.

            _log.Info(targetDirectory.Remove(0, targetDirectory.Length));
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
            {


                
                //To process the file here.
                FileInfo info = new FileInfo(fileName);
                string name = info.Name;
                string extension = info.Extension; // Has period
                DateTime fileTimeInfo = info.CreationTime;
                fileTimeInfo = info.LastAccessTime;
                fileTimeInfo = info.LastWriteTime;

                _log.Info("Finding attachment file: " + name + " ");
                _log.Info("Current filename: " + extension + " ");
                Console.WriteLine(fileTimeInfo);
                Console.WriteLine(fileTimeInfo);
                Console.WriteLine(fileTimeInfo);

                if (name.Trim().ToUpper().Substring(0, 3).Equals("SRA"))
                {
                    _log.Info("Return: " + targetDirectory + "\\" + name);
                    return targetDirectory + "\\" + name;
                }
                else
                {
                    _log.Info("Return Nothing");
                    return "";
                }


            }

            return "";




        }




        public void sendNotification(List<string> bodyText)
        {
            try
            {

                
                myMail.sendEMail a = new myMail.sendEMail();
            
            string listJoined = string.Join(", ", bodyText.ToArray());


                _log.Info("Notification Array: "+bodyText.Count());
                _log.Info(listJoined);



                multiRev.Clear();

                for (int count = 0; count < bodyText.Count; count++)
                {

                    _log.Info("Number of records: " + bodyText.Count());

                    SqlCommand cmd2 = new SqlCommand("select COUNT(*) as RECORD_NUMBER  FROM [inet].[dbo].[dbo.EJOB]  where [JOBNAME] ='" + bodyText.ElementAt(count)+"'" , conn);
                    _log.Info("select COUNT(*) as RECORD_NUMBER   FROM [inet].[dbo].[dbo.EJOB]  where [JOBNAME] ='" + bodyText.ElementAt(count) + "'");
                    Int32 count_recs = (Int32)cmd2.ExecuteScalar();

                    _log.Info("Number of records: "+ count_recs);

                    string stagingText = bodyText.ElementAt(count);
                    PINames.Add(stagingText.Trim().Substring(3));

                    _log.Info(stagingText);
                    _log.Info(PINames.ElementAt(count));
                    _log.Info(bodyText.ElementAt(count));
                    _log.Info((count_recs - 1));
                    _log.Info("TEST--> " + ProcessAttachFile(path + "\\" + "_" + stagingText));
                    
                    if (count_recs > 1)
                    {
                        string attachmentlink = ProcessAttachFile(path + "\\" + "_" + stagingText);
                        a.eMail("eliu@buckman.com", "", "", "E-JOB FILE NOTIFICATION  - Rev. " + (count_recs - 1), "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\"> - Rev.  " + (count_recs - 1) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>", attachmentlink);
                        //a.eMail("eliu@buckman.com", "", "", "E-JOB FILE NOTIFICATION  - Rev. " + (count_recs - 1), "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(count) + " - Rev.  " + (count_recs - 1) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>", attachmentlink);
                        //a.eMail("eliu@buckman.com", "", "", "E-JOB FILE NOTIFICATION FOR " + PINames.ElementAt(count) + " - Rev. "+ (count_recs - 1) , "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(count) + " - Rev.  "+(count_recs - 1)+" </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>", attachmentlink);
                       // a.eMail("eliu@buckman.com", "fchong@buckman.com", "", "E-JOB FILE NOTIFICATION FOR " + PINames.ElementAt(count) + " - Rev. " + (count_recs - 1), "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(count) + " - Rev.  " + (count_recs - 1) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>", attachmentlink);
                      //  _log.Info("eliu@buckman.com"+ "|" + "fchong@buckman.com" + "|" + "" + "|" + "E-JOB FILE NOTIFICATION FOR " + PINames.ElementAt(count) + " - Rev. " + (count_recs - 1) + "|" + "EJOBFILE_NOTIFICATION@buckman.com" + "|" + "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(count) + " - Rev.  " + (count_recs - 1) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>" + "|" + ProcessAttachFile(path + "\\" + "_" + stagingText));
                        _log.Info("MY ERROR ALWAYS SHOWS HERE::" +bodyText.ElementAt(count));
                        multiRev.Add(bodyText.ElementAt(count));
                    }


                    else
                    {

                        for (int counter = 0; counter < multiRev.Count; counter++)
                        {

                            PINames.Remove(multiRev.ElementAt(counter).Trim().Substring(3));
                            bodyText.Remove(multiRev.ElementAt(counter));

                        }

                        string listPIJoined = string.Join(", ", PINames);

                        for (int mailCount = 0; mailCount < bodyText.Count(); mailCount++)
                        {

                            _log.Info("-->" + (path + "\\" + "_" + bodyText.ElementAt(mailCount)));
                            //sending individual email notification
                            //a.eMail("eliu@buckman.com", "", "", "E-JOB FILE NOTIFICATION FOR " + PINames.ElementAt(mailCount), "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(mailCount) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>");
                            a.eMail("eliu@buckman.com", "fchong@buckman.com", "", "E-JOB FILE NOTIFICATION FOR " + PINames.ElementAt(mailCount), "EJOBFILE_NOTIFICATION@buckman.com", "<html>Hi, <br><br>Notification of: <b><a href=\"" + path + "\">" + bodyText.ElementAt(mailCount) + " </a></b>has been updated by CR. <br><br>For your processing please.<br><br>Thank you</html>", ProcessAttachFile(path + "\\" + "_" + bodyText.ElementAt(mailCount)));
                            _log.Info("Mail Sent: " + mailCount);
                        }

                    }

                }

                
            

                    folderNames.Clear();
                    PINames.Clear();
                    conn.Close();
                    conn.Dispose();

            }

            catch(Exception ex)
            {
                myMail.sendEMail errMail = new myMail.sendEMail();
                _log.Info(ex.ToString());
                errMail.eMail("eliu@buckman.com", "", "", "E-JOB FILE ERROR SEND NOTIFICATION", "EJOBFILE_NOTIFICATION@buckman.com", ex.ToString(),"");
                conn.Close();
                conn.Dispose();
            }
        }




    }



}
