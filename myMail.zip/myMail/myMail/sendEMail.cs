﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace myMail
{
    public class sendEMail
    {

        string svrHost = "smtp.buckman.com";
        int svrPort = 25;

        public void eMail(string toAddress, string ccAddress, string bccAddress, string subject, string fromAddress, string bodyMsg, string Filelocation)
        { 

        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
            mail.To.Add(toAddress);
            mail.From = new MailAddress(fromAddress);
            if (ccAddress != string.Empty)
            {
                mail.CC.Add(ccAddress);
            }

            if (bccAddress != string.Empty)
            {
                mail.Bcc.Add(bccAddress);
            }

            if (Filelocation != string.Empty)
            {
                mail.Attachments.Add(new Attachment(Filelocation));
            }

           

            mail.Subject = subject;
            mail.IsBodyHtml = true;
            mail.Body = bodyMsg;

            
            SmtpServer.Host = svrHost;
            SmtpServer.Port = svrPort;
            SmtpServer.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            try
            {
                SmtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception Message: " + ex.Message);
                if (ex.InnerException != null)
                    Debug.WriteLine("Exception Inner:   " + ex.InnerException);
            }
        }

        public void setHost(string hostname)
        {
            svrHost = hostname;
        }

        public void setPort(int Port)
        {
            svrPort = Port;
        }
    }
}
